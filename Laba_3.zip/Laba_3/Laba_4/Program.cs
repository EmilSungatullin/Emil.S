﻿using System;

class Vector
{
    private double[] values;

    public Vector(int n)
    {
        values = new double[n];
    }

    public Vector(double[] values)
    {
        this.values = values;
    }

    public Vector(Vector v)
    {
        this.values = new double[v.size()];
        Array.Copy(v.values, this.values, v.size());
    }

    public int size()
    {
        return values.Length;
    }

    public double get(int i)
    {
        return values[i];
    }

    public void set(int i, double value)
    {
        values[i] = value;
    }

    public static Vector readVectorFromConsole()
    {
        Console.Write("Введите векторное измерение: ");
        int n = int.Parse(Console.ReadLine());
        Vector v = new Vector(n);
        for (int i = 0; i < n; i++)
        {
            Console.Write("Введите значение для компонента {0}: ", i + 1);
            double value = double.Parse(Console.ReadLine());
            v.set(i, value);
        }
        return v;
    }

    public override string ToString()
    {
        string result = "(";
        foreach (double value in values)
        {
            result += value + ",";
        }
        result = result.Substring(0, result.Length - 1) + ")";
        return result;
    }

    public double Length()
    {
        double sum = 0;
        foreach (double value in values)
        {
            sum += value * value;
        }
        return Math.Sqrt(sum);
    }

    public double Max()
    {
        double max = double.MinValue;
        foreach (double value in values)
        {
            if (value > max)
            {
                max = value;
            }
        }
        return max;
    }

    public int MinIndex()
    {
        int minIndex = 0;
        for (int i = 1; i < values.Length; i++)
        {
            if (values[i] < values[minIndex])
            {
                minIndex = i;
            }
        }
        return minIndex;
    }

    public Vector OnlyPositive()
    {
        double[] positiveValues = new double[values.Length];
        int positiveIndex = 0;
        foreach (double value in values)
        {
            if (value > 0)
            {
                positiveValues[positiveIndex++] = value;
            }
        }
        Array.Resize(ref positiveValues, positiveIndex);
        return new Vector(positiveValues);
    }

    public static Vector Add(Vector v1, Vector v2)
    {
        if (v1.size() != v2.size())
        {
            throw new ArgumentException("Векторы имеют разные размеры.");
        }
        double[] resultValues = new double[v1.size()];
        for (int i = 0; i < resultValues.Length; i++)
        {
            resultValues[i] = v1.get(i) + v2.get(i);
        }
        return new Vector(resultValues);
    }

    public static double DotProduct(Vector v1, Vector v2)
    {
        if (v1.size() != v2.size())
        {
            throw new ArgumentException("Векторы имеют разные размеры.");
        }
        double result = 0;
        for (int i = 0; i < v1.size(); i++)
        {
            result += v1.get(i) * v2.get(i);
        }
        return result;
    }

    public static bool Equals(Vector v1, Vector v2)
    {
        if (v1.size() != v2.size())
        {
            return false;
        }
        for (int i = 0; i < v1.size(); i++)
        {
            if (v1.get(i) != v2.get(i))
            {
                return false;
            }
        }
        return true;
    }
}

class VectorTest
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Test 1: Создайте вектор измерения 3 и отобразите его");
        Vector v1 = new Vector(3);
        v1.set(0, 1);
        v1.set(1, 2);
        v1.set(2, 3);
        Console.WriteLine(v1.ToString());

        Console.WriteLine("Test 2: Создать вектор из массива {4,5,6} и покажите это");
        Vector v2 = new Vector(new double[] { 4, 5, 6 });
        Console.WriteLine(v2.ToString());

        Console.WriteLine("Test 3: Создать копию вектора из Test 2 и покажите это");
        Vector v3 = new Vector(v2);
        Console.WriteLine(v3.ToString());

        Console.WriteLine("Test 4: Считывание вектора с консоли и покажите это");
        Vector v4 = Vector.readVectorFromConsole();
        Console.WriteLine(v4.ToString());

        Console.WriteLine("Test 5: \r\nВычислите длину вектора из Test 2 и покажите это");
        Console.WriteLine("Length: " + v2.Length());

        Console.WriteLine("Test 6: Вычислите максимальное значение вектора из Test 2 и покажите это");
        Console.WriteLine("Max: " + v2.Max());

        Console.WriteLine("Test 7: Вычислите индекс минимального значения вектора из Test 2 и покажите это");
        Console.WriteLine("Min Index: " + v2.MinIndex());

        Console.WriteLine("Test 8: Вычислите вектор положительных значений только из вектора из Test 2 и покажите это");
        Vector v5 = v2.OnlyPositive();
        Console.WriteLine(v5.ToString());

        Console.WriteLine("Test 9: Вычислите сумму векторов из Test 1 и Test 2 и покажите это");
        Vector v6 = Vector.Add(v1, v2);
        Console.WriteLine(v6.ToString());

        Console.WriteLine("Test 10: Вычислите точечное произведение векторов из Test 1 и Test 2 и покажите это");
        double dotProduct = Vector.DotProduct(v1, v2);
        Console.WriteLine("Dot Product: " + dotProduct);

        Console.WriteLine("Test 11: Проверьте, являются ли векторы из Test 2 и Test 3 равны");
        bool equals = Vector.Equals(v2, v3);
        Console.WriteLine("Equals: " + equals);

        Console.WriteLine("Test 12: Проверьте, являются ли векторы из Test 2 и Test 4 равны");
        equals = Vector.Equals(v2, v4);
        Console.WriteLine("Equals: " + equals);
    }
}
