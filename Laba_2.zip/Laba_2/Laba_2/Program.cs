﻿using System;

class Person
{
    public string Name { get; set; }
    public string Surname { get; set; }
    private DateTime _birthDate;
    public char Gender { get; set; }

    public Person()
    {
        Name = "";
        Surname = "";
        _birthDate = new DateTime();
        Gender = ' ';
    }

    public Person(string Name, string surName, DateTime birthDate, char gender)
    {
        Name = Name;
        Surname = surName;
        BirthDate = birthDate;
        Gender = gender;
    }

    public Person(Person p)
    {
        Name = p.Name;
        Surname = p.Surname;
        BirthDate = p.BirthDate;
        Gender = p.Gender;
    }

    public DateTime BirthDate
    {
        get { return _birthDate; }
        set
        {
            DateTime today = DateTime.Today;
            int age = today.Year - value.Year;
            if (value > today.AddYears(-age))
                age--;
            if (age < 0 || age > 120)
                throw new ArgumentException("Неверная дата рождения");
            _birthDate = value;
        }
    }

    public int Age
    {
        get { return DateTime.Today.Year - _birthDate.Year - ((_birthDate.Month > DateTime.Today.Month || (_birthDate.Month == DateTime.Today.Month && _birthDate.Day > DateTime.Today.Day)) ? 1 : 0); }
    }

    public override string ToString()
    {
        return $"{Surname} {Name[0]}. {Age} {Gender}";
    }

    public static void ReadArray(Person[] persons)
    {
        for (int i = 0; i < persons.Length; i++)
        {
            Console.WriteLine($"Person {i + 1}:");
            Console.Write("Напишите имя: ");
            persons[i].Name = Console.ReadLine();
            Console.Write("Напишите фамилию: ");
            persons[i].Surname = Console.ReadLine();
            Console.Write("Напишите дату рождения (гггг-мм-дд): ");
            persons[i].BirthDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Напишите гендер (М/Ж): ");
            persons[i].Gender = char.Parse(Console.ReadLine());
            Console.WriteLine();
        }
    }

    public static void PrintArray(Person[] persons)
    {
        foreach (Person p in persons)
        {
            Console.WriteLine(p.ToString());
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Напишите кол-во человек: ");
        int n = int.Parse(Console.ReadLine());
        Person[] persons = new Person[n];
        for (int i = 0; i < n; i++)
        {
            persons[i] = new Person();
        }
        Person.ReadArray(persons);
        Console.WriteLine();
        Person.PrintArray(persons);
    }
}