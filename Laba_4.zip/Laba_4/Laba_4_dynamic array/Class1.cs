﻿using Laba4;
using System;

double[] c = { 1, 2, 3, 4, 5 };
dynamicarray a = new dynamicarray(c);
a.append(7);
Console.WriteLine(a);
a.append(5, 6);
Console.WriteLine(a);
a.delete();
Console.WriteLine(a);
a.deleteIn(2);
Console.WriteLine(a);
a.append(7);
Console.WriteLine(a);
a.delete(5);
Console.WriteLine(a);
Console.WriteLine(a.Size);
